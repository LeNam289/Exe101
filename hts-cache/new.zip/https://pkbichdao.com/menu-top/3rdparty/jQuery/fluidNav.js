<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="REFRESH" content="1800" />
<title>404 Not Found</title>
<meta name="DESCRIPTION"  content=""/>
<meta name="KEYWORDS" content=""/>
<style>
body{
	background:url("/App/images/topbg.png") repeat-x 0 0 #f5f5f5;
}
.wrap404{
	background:url('/App/images/bg.png') no-repeat center top;
	padding-top:150px;
}
.ct404 {
	width: 600px;
	margin:auto;
	border: 1px solid #ccc;
	padding: 20px;
	background: #fff;
	border-radius: 5px;
}
.img404{
	padding: 19px 42px 0px 15px;
	float: left;
}
div.rightUp_404:after{
	content:".";
	display:block;
	clear:both;
	visibility:hidden;
	height:0;
	width:0;
	line-height:0;
}
.sorry span {
	font: bold 60px tahoma;
	color: #6f6f66;
	padding: 0px 32px 0px 0px;
	text-shadow: 0px 0px 1px #6f6f6f;
}
.notLink {
	font: 18px tahoma;
	color: #6f6f66;
	margin: 0px 0px 15px;
}
.aBack {
	float: left;
	font: bold 11px arial;
	text-decoration:none;
	color: #005599;
	text-transform: uppercase;
}
.aBack:hover{
	text-decoration:underline;
</style>
</head>
<body>
<div id="wrap">
    <div id="content">
        <div class="wrap404">
            <div class="ct404">
                <div class="up_404">
                    <div class="img404"><img alt="404" title="404" src="/404-not-found.gif" width="226" height="163" /> </div>
                    <div class="rightUp_404">
                        <p class="sorry"><span>Sorry!</span> </p>
                        <p class="notLink">The link you are looking for is currently unavailable.</p>
                        <p class="pBack"><a href="/" rel="nofollow" class="aBack">Back to home</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
